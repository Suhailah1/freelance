CREATE DATABASE `userdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci / /!80016 DEFAULT ENCRYPTION='N' */;

-- userdb.job definition

CREATE TABLE `job` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) 

INSERT INTO userdb.job (name) VALUES('Information Technology (IT)');
INSERT INTO userdb.job (name) VALUES('Cyber Security');
INSERT INTO userdb.job (name) VALUES('Artificial Intelligence (Ai)');
INSERT INTO userdb.job (name) VALUES('Cloud Computing');
INSERT INTO userdb.job (name) VALUES('Network Computing');
INSERT INTO userdb.job (name) VALUES('Internet of Things (IoT)');

-- userdb.info definition

CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `age` int NOT NULL,
  `phone` varchar(100) CHARACTER SET NOT NULL,
  `email` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `info_FK` (`jobId`),
  CONSTRAINT `info_FK` FOREIGN KEY (`jobId`) REFERENCES `job` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=13;

INSERT INTO `` (`id`,`name`,`age`,`phone`,`email`) VALUES (1,'Chris Hemsworth',33,'01238643234',chris@gmail.com);
INSERT INTO `` (`id`,`name`,`age`,`phone`,`email`) VALUES (2,'Alana Lam Hemsworthf',27,'0112689003',Alana@gmail.com);
INSERT INTO `` (`id`,`name`,`age`,`phone`,`email`) VALUES (11,'Marrisa Edward',23,'0184934585',Marissa12@gmail.com);
INSERT INTO `` (`id`,`name`,`age`,`phone`,`email`) VALUES (12,'Shahrul Isham',30,'0128766531',shahrul07@gmail,com);