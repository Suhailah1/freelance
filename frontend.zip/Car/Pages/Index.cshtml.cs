﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Car.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }

        public void OnPost()
        {
            string textBoxValue = Request.Form["myTextbox"];
            // Do something with the value
          
        }


        public class ButtonPageModel : PageModel
        {
            public IActionResult OnPost()
            {
                // C# code to execute when the button is clicked
                // This method will be called when the button is clicked
                // You can perform any server-side logic here
                return Page();
            }
        }

    }
}